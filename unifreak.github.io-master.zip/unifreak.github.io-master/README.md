# My github pages

My blog. On IT tech, personal thoughts and so on....

Built on github pages, powered by jekyll.
Served at <https://unifreak.github.io>

If you are insterested in the blog's jekyll theme, see [jekyll-theme-textalic](https://github.com/UniFreak/jekyll-theme-textalic)

